package miproyecto;

import Geometria.Circulo;

public class MiProyecto {

    //Método de inicio
    public static void main(String[] args) {

        /*Parte 1 - Strings y concatenación*/
        String forma_1 = "Mi texto";
        String forma_2 = new String("Mi texto");
        System.out.println("Hola" + " mundo" + " :)");

        int valor_1 = 23;
        float valor_2 = 50;
        boolean valor_3 = true;//Concatenando diferentes tipos de datos primitivos
        System.out.println("Mi resultado:" + (valor_1 + valor_2) + " - " + valor_3);

        /*Parte 2*/
        //Instanciando un objeto de tipo Círculo
        Circulo circulo = new Circulo(5);
        circulo.setRadio(7); //Actualizando valor del atributo radio

        float radio = circulo.getRadio();//Obteniendo el radio del círculo
        float area = circulo.obtenerArea();//Obteniendo el área del círculo
        float perimetro = circulo.obtenerPerimetro();//Obteniendo el perímetro del círculo
        //Mostrando datos obtenidos
        System.out.println("Radio:" + radio + " Área:" + area + " Perímetro:" + perimetro);

        /*Parte 3*/
        Perro pug = new Perro("Pug", 0.5f);
        Perro golden = new Perro("Golden", 1.5f);
        //Mostrando datos obtenidos
        System.out.println("Raza:" + pug.getRaza() + " Peso:" + pug.getPeso() + "\n"
                         + "Raza:" + golden.getRaza() + " Peso:" + golden.getPeso());
    }
}
