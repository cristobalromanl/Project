package miproyecto;

public class Perro {

    /*Atributos - Tipo privado - Solamente se puede utilizar dentro de la clase*/
    private String raza;
    private float peso;

    /*Constructor*/
    public Perro(String raza, float peso) {
        //Asignando valores a los atributos 
        this.raza = raza;
        this.peso = peso;
    }

    /*Métodos para obtener y actualizar valores asociado a los atributos*/
    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }
}
