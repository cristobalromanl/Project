package Geometria;

/*Clase Círculo*/
public class Circulo {

    /*Atributos - Tipo privado - Solamente se puede utilizar dentro de la clase*/
    private float pi;
    private float radio;

    /*Constructor*/
    public Circulo(float radio) {
        //Asignado un valor flotante al atributo pi
        pi = 3.1415f;
        this.radio = radio;
    }

    /*Metodos*/
    public float obtenerArea() {
        return 3.141516f * radio * radio;
    }

    public float obtenerPerimetro() {
        return 2 * 3.1415f * radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }
}
