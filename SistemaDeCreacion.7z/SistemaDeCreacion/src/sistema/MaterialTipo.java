package sistema;

public enum MaterialTipo {
    MADERA,
    PIEDRA,
    CUERDA,
    LANA,
    AGUA,
    HARINA
}
