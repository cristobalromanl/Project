package sistema;

public enum ProductoTipo {
    SILLA,
    MESA,
    GORRO,
    HACHA,
    PAN,
    REFUGIO
}
